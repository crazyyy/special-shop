<ul class="details multipane">
	<li>
		<div id="details-menu" class="multiple-select menu">
		<input type="hidden" name="deletedSpecs" id="test" class="deletes" value="" />
		<ul></ul>
		</div>
	</li>
	<li><div id="details-list" class="list"><ul></ul></div></li>
</ul><br class="clear" />
<div id="new-detail">
<button type="button" id="addDetail" class="button-secondary" tabindex="8"><small><?php _e('Add Product Detail','Shopp'); ?></small></button>
<p><?php _e('Build a list of detailed information such as dimensions or features of the product.','Shopp'); ?></p>
</div>